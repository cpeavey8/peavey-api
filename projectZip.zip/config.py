"""
Wrapper to support both import styles
"""
from api_root.config import *
